import Footer from "./footer/Footer";
import Navbar from "./header/Navbar";
import ServiceCard from "./ServiceCard";
import Login from "./Login"
import LandingPage from "./LandingPage"
import Banner from "./Banner";
import Testimonial from "./Testimonial";
import ServiceDetail from "../pages/services/ServiceDetail"
import HeaderLine from "./HeaderLine";
import EmployeeCard from "./EmployeeCard";
export {
    Navbar, Footer, ServiceCard, Login, LandingPage, Banner, Testimonial, ServiceDetail, HeaderLine, EmployeeCard
}
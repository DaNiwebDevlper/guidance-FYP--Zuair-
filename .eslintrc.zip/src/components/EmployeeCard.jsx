import React from 'react'

const EmployeeCard = ({ employeeData }) => {
    return (
        <div className='p-5 sm:w-[380px] bg-slate-50 w-[300px] min-h-[280px] border rounded justify-center items-center flex flex-col gap-y-5 shadow-md hover:scale-105 transition-all cursor-pointer'>
            <div className="">
                <img src={employeeData.imgSrc} alt={employeeData.title} className='w-[200px] h-[200px] object-cover rounded-full' />
            </div>
            <h1 className='text-2xl font-mono font-semibold text-center'>{employeeData.title}</h1>
            <p className='text-sm text-black/70 text-center font-sans'>{employeeData.desc}</p>
        </div>
    )
}

export default EmployeeCard
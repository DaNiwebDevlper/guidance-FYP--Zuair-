import React from 'react'
import servicesData from "../../data/servicesData"
import { ServiceCard } from '../../components'
import { Link } from 'react-router-dom'

const Services = () => {
  return (
    <div className=' min-h-screen flex flex-col justify-center items-center gap-y-9 sm:p-0 p-9'>
      <h1 className='text-4xl font-semibold font-mono text-center mt-9'>Our Services</h1>
      <div className="flex flex-wrap gap-5 justify-center items-center w-full mt-9">
        {servicesData.map((data) => {
          return (
            <Link to={`/services/${data.id}`}>
              <ServiceCard servicesData={data} />
            </Link>
          )
        })}
      </div>
    </div>
  )
}

export default Services

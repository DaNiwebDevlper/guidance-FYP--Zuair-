import { EmployeeCard } from "../../components"
import ServicesData from "../../data/servicesData.json"
import { useParams } from 'react-router-dom'

const ServiceDetail = () => {
    const params = useParams()
    return (
        <div>

            {ServicesData.map((data) => {
                return (params.id == data.id && (
                    <EmployeeCard employeeData={data} />

                ))

            })}


        </div>
    )
}

export default ServiceDetail
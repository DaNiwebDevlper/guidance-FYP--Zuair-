import { Route, RouterProvider } from 'react-router-dom'
import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import { createBrowserRouter, createRoutesFromElements } from 'react-router-dom'
import Layout from './layout'
import Home from './pages/homepage/Home'
import AboutPage from './pages/about/About'
import Contact from './pages/contact/Contact'
import Services from './pages/services/Services'
import Login from './components/Login'
import ServiceDetail from "./pages/services/ServiceDetail"
import Register from './components/Register'


const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<Layout />}>
      <Route path='/' element={<Home />} />
      <Route path='/about' element={<AboutPage />} />
      <Route path='/contact' element={<Contact />} />
      <Route path='/services' element={<Services />} />
      <Route path='/services/:id' element={<ServiceDetail />} />
      <Route path='/login' element={<Login />} />
      <Route path='/sign-up' element={<Register />} />
    </Route>
  )
)

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>,
)